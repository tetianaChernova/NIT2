import './css/bootstrap.css';
import './scss/main.scss';
import 'bootstrap';
import './js/getcategory';
import './js/bin';